let index = 0;
function moveSlide(step) {
    const carousel = document.querySelector('.carousel');
    const cards = document.querySelectorAll('.card');
    const totalCards = cards.length;
    const cardWidth = cards[0].offsetWidth + 20;
    index += step;
    if (index < 0) index = totalCards - 1;
    if (index >= totalCards) index = 0;
    carousel.style.transform = `translateX(${-index * cardWidth}px)`;
}


    document.getElementById("search-btn").addEventListener("click", function() {
        alert("Search functionality coming soon!");
    });